using ScamReady.Responses;
using ScamReady.Scenarios;
using TMPro;
using UnityEngine;
using ScamReady.UI;

namespace ScamReady.Feedback
{
    public sealed class ScenarioResultView : MonoBehaviour
    {
        [SerializeField] private ScenarioController controller;
        [SerializeField] private GameObject window;
        [SerializeField] private TMP_Text scenarioText;
        [SerializeField] private TMP_Text titleText;
        [SerializeField] private TMP_Text processText;
        [SerializeField] private TMP_Text bodyText;
        [SerializeField] private UnityEngine.UI.ScrollRect bodyScroll;
        [SerializeField] private UnityEngine.UI.Button restartButton;
        [SerializeField] private UnityEngine.UI.Button nextScenarioButton;

        [Header("Audio")]
        [SerializeField] private UIAudioPlayer audioPlayer;

        private ScenarioEvaluation displayedResult;
        private bool displayingPhoneResult;

        private void Awake()
        {
            restartButton.onClick.AddListener(controller.Restart);
            if (nextScenarioButton != null) nextScenarioButton.onClick.AddListener(controller.NextScenario);
            titleText.richText = false;
            bodyText.richText = false;

            if (audioPlayer == null)
            {
                audioPlayer = GetComponentInParent<UIAudioPlayer>();
            }

        }

        private void OnEnable()
        {
            controller.Changed += Refresh;
            Refresh();
        }

        private void OnDisable()
        {
            controller.Changed -= Refresh;
        }

        private void OnDestroy()
        {
            restartButton.onClick.RemoveListener(controller.Restart);
            if (nextScenarioButton != null) nextScenarioButton.onClick.RemoveListener(controller.NextScenario);
        }

        private void Refresh()
        {
            if (nextScenarioButton != null)
            {
                nextScenarioButton.gameObject.SetActive(controller.HasPlaylist);
                nextScenarioButton.interactable = controller.CanStartNextScenario;
            }
            var result = controller.Result;
            if (result == null)
            {
                displayedResult = null;
                RefreshPhoneResult();
                return;
            }

            displayingPhoneResult = false;
            bool resultChanged = result != displayedResult;
            if (resultChanged)
            {
                RefreshContent(result);
                displayedResult = result;
                PlayResultSound(result);
            }
            Show();
            if (resultChanged) ResetScroll();
        }

        private void RefreshPhoneResult()
        {
            if (!controller.PhoneDecision.HasValue)
            {
                displayingPhoneResult = false;
                Hide();
                return;
            }

            if (!displayingPhoneResult)
            {
                scenarioText.text = "Call complete  |  "
                    + (controller.PhoneLevel != null ? controller.PhoneLevel.Title : string.Empty);
                titleText.text = controller.PhoneOutcomeTitle;
                string response = controller.PhoneDecision.Value == ScamReady.Phone.PhoneResponse.Trust ? "Proceed"
                    : controller.PhoneDecision.Value == ScamReady.Phone.PhoneResponse.Report ? "Reject / Report" : "Ignore";
                processText.text = "Your response: " + response
                    + "\nEvidence at decision: " + controller.CollectedPhoneEvidenceCount
                    + " / " + controller.RequiredPhoneEvidenceCount;
                bodyText.text = controller.PhoneOutcomeBody;
                displayingPhoneResult = true;
                if (audioPlayer != null)
                {
                    if (controller.PhoneDecision.Value == ScamReady.Phone.PhoneResponse.Report)
                        audioPlayer.PlaySuccess();
                    else
                        audioPlayer.PlayWarning();
                }
                Show();
                ResetScroll();
                return;
            }

            Show();
        }

        private void RefreshContent(ScenarioEvaluation result)
        {
            var message = controller.Definition.Feedback.GetMessage(result.Outcome);
            scenarioText.text = "Scenario complete  |  " + controller.Definition.Title;
            titleText.text = message.Title;
            string body = message.Body;
            string warning = controller.Definition.Feedback.UnsafeLinkWarning;
            if (result.UnsafeLinkCount > 0 && result.Outcome != ScenarioOutcome.Proceed
                && !string.IsNullOrWhiteSpace(warning)) body += "\n\n" + warning;
            bodyText.text = FormatFeedbackBody(body, result);
            RefreshDecisionSummary(result);
        }

        private void PlayResultSound(ScenarioEvaluation result)
        {
            if (audioPlayer == null)
                return;

            if (result.HasSupportedDecision)
            {
                audioPlayer.PlaySuccess();
            }
            else
            {
                audioPlayer.PlayWarning();
            }
        }

        private static string FormatFeedbackBody(string body, ScenarioEvaluation result)
        {
            return (body ?? string.Empty)
                .Replace("{evidenceCount}", result.EvidenceCount.ToString())
                .Replace("{requiredCount}", result.RequiredEvidenceCount.ToString())
                .Replace("{collectedRequiredCount}", result.CollectedRequiredEvidenceCount.ToString())
                .Replace("{unsafeLinkCount}", result.UnsafeLinkCount.ToString());
        }

        private void RefreshDecisionSummary(ScenarioEvaluation result)
        {
            string response = result.Response == ContactResponse.Reject ? "Reject / Report" : result.Response.ToString();
            string verification = result.HasCompleteVerification ? "Complete verification"
                : result.EvidenceCount == 0
                    ? result.Response == ContactResponse.Reject ? "No evidence submitted" : "No evidence collected"
                    : "Incomplete verification";
            string evidenceLabel = result.Response == ContactResponse.Reject
                ? "Evidence submitted: " : "Evidence at decision: ";
            processText.text = "Your decision: " + response + "\n"
                + evidenceLabel + result.EvidenceCount + "  |  Required: "
                + result.CollectedRequiredEvidenceCount + "/" + result.RequiredEvidenceCount
                + "\n" + verification
                + (result.IsLegitimateContact ? "\nThis was a genuine notice." : string.Empty);
        }

        public void Show()
        {
            if (window.activeSelf) return;
            window.SetActive(true);
            BringToFront();
        }

        public void Hide()
        {
            if (!window.activeSelf) return;
            window.SetActive(false);
        }

        private void BringToFront()
        {
            window.transform.SetAsLastSibling();
            transform.SetAsLastSibling();
        }

        private void ResetScroll()
        {
            Canvas.ForceUpdateCanvases();
            bodyScroll.StopMovement();
            bodyScroll.verticalNormalizedPosition = 1f;
        }
    }
}
