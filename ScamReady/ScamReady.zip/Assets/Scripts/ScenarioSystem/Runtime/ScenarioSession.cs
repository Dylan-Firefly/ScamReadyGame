using System.Collections.Generic;
using ScamReady.Responses;

namespace ScamReady.Scenarios
{
    public enum ScenarioApp
    {
        Desktop,
        Email,
        Phone,
        Browser,
        Result
    }

    public enum ScenarioEventType
    {
        // Keep serialized event IDs stable; assign new IDs to new events.
        EmailReceived = 0,
        EmailOpened = 1,
        EmailClosed = 2,
        ContactStopped = 3,
        ResponseChosen = 4,
        BrowserOpened = 5,
        BrowserClosed = 6,
        VerificationPageOpened = 7,
        EvidenceCollected = 8,
        EvidenceSummaryOpened = 9,
        ReminderTriggered = 10,
        ReminderDismissed = 11,
        UnsafeLinkOpened = 12,
        InformationSubmitted = 13,
        PhoneOpened = 14,
        PhoneClosed = 15
    }

    public sealed class ScenarioEvent
    {
        public int SequenceIndex { get; }
        public double ElapsedSeconds { get; }
        public ScenarioEventType Type { get; }
        public string TargetId { get; }

        internal ScenarioEvent(int sequenceIndex, double elapsedSeconds, ScenarioEventType type, string targetId)
        {
            SequenceIndex = sequenceIndex;
            ElapsedSeconds = elapsedSeconds;
            Type = type;
            TargetId = targetId;
        }
    }

    public sealed class ScenarioSession
    {
        private readonly List<ScenarioEvent> history = new List<ScenarioEvent>();
        private readonly List<string> collectedEvidenceIds = new List<string>();
        private readonly string emailId;
        private string reminderId;

        public string ScenarioId { get; }
        public ScenarioApp ActiveApp { get; private set; }
        public bool IsEmailOpen => ActiveApp == ScenarioApp.Email;
        public bool IsPhoneOpen => ActiveApp == ScenarioApp.Phone;
        public bool IsBrowserOpen => ActiveApp == ScenarioApp.Browser;
        public string CurrentVerificationPageId { get; private set; }
        public bool HasReadEmail { get; private set; }
        public bool HasUnreadEmail => !string.IsNullOrWhiteSpace(emailId) && !HasReadEmail;
        public ContactResponse? Decision { get; private set; }
        public bool IsComplete => Decision.HasValue;
        public IReadOnlyList<ScenarioEvent> History { get; }
        public IReadOnlyList<string> CollectedEvidenceIds { get; }
        public IReadOnlyList<string> DecisionEvidenceIds { get; private set; }
        public IReadOnlyList<string> SubmittedEvidenceIds { get; private set; }
        public bool IsEvidenceSubmissionOpen { get; private set; }
        public int? DecisionSequenceIndex { get; private set; }
        public int DecisionUnsafeLinkCount { get; private set; }
        public bool IsEvidenceSummaryOpen { get; private set; }
        public bool HasTriggeredReminder { get; private set; }
        public bool IsReminderVisible { get; private set; }

        internal ScenarioSession(string scenarioId, string emailId)
        {
            ScenarioId = scenarioId;
            this.emailId = emailId;
            History = history.AsReadOnly();
            CollectedEvidenceIds = collectedEvidenceIds.AsReadOnly();
            DecisionEvidenceIds = new List<string>().AsReadOnly();
            SubmittedEvidenceIds = new List<string>().AsReadOnly();
            if (!string.IsNullOrWhiteSpace(emailId))
                Record(ScenarioEventType.EmailReceived, emailId, 0);
        }

        internal bool OpenPhone(double elapsedSeconds)
        {
            if (IsComplete || IsPhoneOpen) return false;
            if (IsEmailOpen) Record(ScenarioEventType.EmailClosed, emailId, elapsedSeconds);
            if (IsBrowserOpen) Record(ScenarioEventType.BrowserClosed, ScenarioId, elapsedSeconds);
            ActiveApp = ScenarioApp.Phone;
            Record(ScenarioEventType.PhoneOpened, ScenarioId, elapsedSeconds);
            return true;
        }

        internal bool ClosePhone(double elapsedSeconds)
        {
            return ClosePhone(false, elapsedSeconds);
        }

        internal bool ClosePhone(bool stopContact, double elapsedSeconds)
        {
            if (!IsPhoneOpen) return false;
            ActiveApp = ScenarioApp.Desktop;
            Record(stopContact ? ScenarioEventType.ContactStopped : ScenarioEventType.PhoneClosed,
                ScenarioId, elapsedSeconds);
            return true;
        }
        

        internal bool OpenEmail(double elapsedSeconds)
        {
            if (IsComplete || IsEvidenceSummaryOpen || IsEvidenceSubmissionOpen)
                return false;
            if (IsBrowserOpen) Record(ScenarioEventType.BrowserClosed, ScenarioId, elapsedSeconds);
            if (IsPhoneOpen) Record(ScenarioEventType.PhoneClosed, ScenarioId, elapsedSeconds);
            ActiveApp = ScenarioApp.Email;
            HasReadEmail = true;
            Record(ScenarioEventType.EmailOpened, emailId, elapsedSeconds);
            return true;
        }

        internal bool CloseEmail(bool stopContact, double elapsedSeconds)
        {
            if (!IsEmailOpen || IsEvidenceSubmissionOpen) return false;
            ActiveApp = ScenarioApp.Desktop;
            Record(stopContact ? ScenarioEventType.ContactStopped : ScenarioEventType.EmailClosed,
                emailId, elapsedSeconds);
            return true;
        }


        internal bool ChooseResponse(ContactResponse response, double elapsedSeconds)
        {
            if (!IsEmailOpen || IsComplete) return false;

            if (response != ContactResponse.Proceed &&
                response != ContactResponse.Ignore &&
                response != ContactResponse.Reject)
                return false;

            if (response == ContactResponse.Reject)
                return OpenEvidenceSubmission(elapsedSeconds);

            if (IsEvidenceSubmissionOpen)
                return false;

            CompleteDecision(response, elapsedSeconds);
            return true;
        }

        internal bool ChoosePhoneResponse(ContactResponse response, double elapsedSeconds)
        {
            if (!IsPhoneOpen || IsComplete) return false;
            if (response != ContactResponse.Proceed && response != ContactResponse.Ignore
                && response != ContactResponse.Reject) return false;
            CompleteDecision(response, elapsedSeconds);
            return true;
        }

        internal bool OpenEvidenceSubmission(double elapsedSeconds)
        {
            if (!IsEmailOpen || IsComplete || IsEvidenceSubmissionOpen)
                return false;
            IsEvidenceSubmissionOpen = true;
            IsEvidenceSummaryOpen = false;
            return true;
        }

        internal bool CloseEvidenceSubmission()
        {
            if (!IsEvidenceSubmissionOpen || IsComplete)
                return false;
            IsEvidenceSubmissionOpen = false;
            return true;
        }

        internal bool SubmitEvidence(IReadOnlyList<string> selectedIds, double elapsedSeconds)
        {
            if (!IsEvidenceSubmissionOpen || !IsEmailOpen || IsComplete || selectedIds == null)
                return false;

            var selected = new HashSet<string>();
            foreach (string id in selectedIds)
            {
                if (string.IsNullOrWhiteSpace(id) || !collectedEvidenceIds.Contains(id))
                    return false;
                selected.Add(id);
            }

            SubmittedEvidenceIds = new List<string>(selected).AsReadOnly();
            CompleteDecision(ContactResponse.Reject, elapsedSeconds);
            return true;
        }
        internal bool SubmitInformation(string pageId, double elapsedSeconds)
        {
            if (!IsBrowserOpen || IsComplete || CurrentVerificationPageId != pageId) return false;
            Record(ScenarioEventType.InformationSubmitted, pageId, elapsedSeconds);
            CompleteDecision(ContactResponse.Proceed, elapsedSeconds);
            return true;
        }

        internal bool RecordUnsafeLinkOpened(string pageId, double elapsedSeconds)
        {
            if (!IsBrowserOpen || IsComplete || CurrentVerificationPageId != pageId) return false;
            Record(ScenarioEventType.UnsafeLinkOpened, pageId, elapsedSeconds);
            return true;
        }

        private void CompleteDecision(ContactResponse response, double elapsedSeconds)
        {
            Decision = response;
            // Snapshot evidence when the player decides.
            DecisionEvidenceIds = new List<string>(collectedEvidenceIds).AsReadOnly();
            // Freeze risky actions at the decision point.
            foreach (var action in history)
                if (action.Type == ScenarioEventType.UnsafeLinkOpened) DecisionUnsafeLinkCount++;
            DecisionSequenceIndex = history.Count + 1;
            ActiveApp = ScenarioApp.Result;
            IsEvidenceSummaryOpen = false;
            IsEvidenceSubmissionOpen = false;
            IsReminderVisible = false;
            Record(ScenarioEventType.ResponseChosen, response.ToString(), elapsedSeconds);
        }

        internal bool OpenBrowser(double elapsedSeconds)
        {
            if (IsComplete || IsBrowserOpen) return false;
            if (IsEmailOpen) CloseEmail(false, elapsedSeconds);
            if (IsPhoneOpen) Record(ScenarioEventType.PhoneClosed, ScenarioId, elapsedSeconds);
            ActiveApp = ScenarioApp.Browser;
            Record(ScenarioEventType.BrowserOpened, ScenarioId, elapsedSeconds);
            return true;
        }

        internal bool CloseBrowser(double elapsedSeconds)
        {
            if (!IsBrowserOpen) return false;
            ActiveApp = ScenarioApp.Desktop;
            Record(ScenarioEventType.BrowserClosed, ScenarioId, elapsedSeconds);
            return true;
        }

        internal bool OpenBrowserHome()
        {
            if (!IsBrowserOpen || CurrentVerificationPageId == null) return false;
            CurrentVerificationPageId = null;
            return true;
        }

        internal bool OpenVerificationPage(string pageId, double elapsedSeconds)
        {
            if (!IsBrowserOpen || CurrentVerificationPageId == pageId) return false;
            CurrentVerificationPageId = pageId;
            Record(ScenarioEventType.VerificationPageOpened, pageId, elapsedSeconds);
            return true;
        }

        private void Record(ScenarioEventType type, string targetId, double elapsedSeconds)
        {
            history.Add(new ScenarioEvent(history.Count + 1, elapsedSeconds, type, targetId));
        }

        public bool HasCollectedEvidence(string id) => collectedEvidenceIds.Contains(id);

        internal bool CollectEvidence(string id, double elapsedSeconds)
        {
            if (!IsBrowserOpen || HasCollectedEvidence(id)) return false;
            collectedEvidenceIds.Add(id);
            Record(ScenarioEventType.EvidenceCollected, id, elapsedSeconds);
            return true;
        }

        internal bool CollectPhoneEvidence(string id, double elapsedSeconds)
        {
            if (!IsPhoneOpen || HasCollectedEvidence(id)) return false;
            collectedEvidenceIds.Add(id);
            Record(ScenarioEventType.EvidenceCollected, id, elapsedSeconds);
            return true;
        }

        internal bool OpenEvidenceSummary(double elapsedSeconds)
        {
            if (IsComplete || IsEvidenceSummaryOpen) return false;
            IsEvidenceSummaryOpen = true;
            Record(ScenarioEventType.EvidenceSummaryOpened, ScenarioId, elapsedSeconds);
            return true;
        }

        internal bool CloseEvidenceSummary()
        {
            if (!IsEvidenceSummaryOpen) return false;
            IsEvidenceSummaryOpen = false;
            return true;
        }

        internal bool TriggerReminder(string id, double elapsedSeconds)
        {
            if (HasTriggeredReminder || Decision.HasValue) return false;
            reminderId = id;
            HasTriggeredReminder = true;
            IsReminderVisible = true;
            Record(ScenarioEventType.ReminderTriggered, id, elapsedSeconds);
            return true;
        }

        internal bool DismissReminder(double elapsedSeconds)
        {
            if (!IsReminderVisible) return false;
            IsReminderVisible = false;
            Record(ScenarioEventType.ReminderDismissed, reminderId, elapsedSeconds);
            return true;
        }
    }
}
