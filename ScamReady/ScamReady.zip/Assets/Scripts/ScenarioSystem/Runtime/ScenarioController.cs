using System;
using System.Collections.Generic;
using ScamReady.Evidence;
using ScamReady.Feedback;
using ScamReady.Phone;
using ScamReady.Responses;
using ScamReady.Verification;
using UnityEngine;

namespace ScamReady.Scenarios
{
    public enum ScenarioType
    {
        Email,
        Phone
    }

    public sealed class ScenarioController : MonoBehaviour
    {
        [Header("Scenario playlist")]
        [SerializeField, Tooltip("Optional playlist. Leave empty to run a single scenario.")]
        private ScenarioPlaylist playlist;
        [Header("Current scenario")]
        [SerializeField] private ScenarioType scenarioType;
        [SerializeField, Tooltip("Scenario definition used in Email mode.")]
        private EmailScenarioDefinition definition;
        [Header("Phone scenario data")]
        [SerializeField] private PhoneScenarioCollection phoneCollection;
        [SerializeField, Min(0)] private int phoneLevelIndex;

        private readonly HashSet<string> collectedPhoneEvidenceIds = new HashSet<string>();
        private double startedAt;
        private double callStartedAt;
        private double completedCallDurationSeconds;
        private readonly Queue<ScenarioPlaylistEntry> pendingScenarios = new Queue<ScenarioPlaylistEntry>();
        private readonly List<ScenarioPlaylistEntry> availableScenarios = new List<ScenarioPlaylistEntry>();
        private ScenarioPlaylistEntry currentEntry;

        public EmailScenarioDefinition Definition => definition;
        public ScenarioType CurrentScenarioType => scenarioType;
        public bool IsEmailScenario => scenarioType == ScenarioType.Email;
        public bool IsPhoneScenario => scenarioType == ScenarioType.Phone;
        public ScenarioSession Session { get; private set; }
        public ScenarioEvaluation Result { get; private set; }
        public PhoneScenarioLevel PhoneLevel { get; private set; }
        public string CurrentScenarioId => IsPhoneScenario ? PhoneLevel?.Id : definition?.Id;
        public string CurrentScenarioTitle => IsPhoneScenario ? PhoneLevel?.Title : definition?.Title;
        public string CurrentScenarioSetup => IsPhoneScenario ? PhoneLevel?.Setup : definition?.Setup;
        public string CurrentScenarioDateText => IsEmailScenario ? definition?.GameDateText : string.Empty;
        public string CurrentContactName => IsPhoneScenario
            ? PhoneLevel?.CallerName
            : definition?.Email?.Sender;
        public IReadOnlyList<VerificationPageDefinition> VerificationPages =>
            IsPhoneScenario ? PhoneLevel?.VerificationPages ?? Array.Empty<VerificationPageDefinition>()
            : definition?.VerificationPages ?? Array.Empty<VerificationPageDefinition>();
        public IReadOnlyList<VerificationPageDefinition> LinkedPages =>
            IsPhoneScenario ? PhoneLevel?.LinkedPages ?? Array.Empty<VerificationPageDefinition>()
            : definition?.LinkedPages ?? Array.Empty<VerificationPageDefinition>();
        public IReadOnlyList<EvidencePlacement> EvidencePlacements =>
            IsPhoneScenario ? PhoneLevel?.EvidencePlacements ?? Array.Empty<EvidencePlacement>()
            : definition?.EvidencePlacements ?? Array.Empty<EvidencePlacement>();
        public PhoneCallState CallState { get; private set; }
        public PhoneResponse? PhoneDecision { get; private set; }
        public string PhoneOutcomeTitle { get; private set; }
        public string PhoneOutcomeBody { get; private set; }
        public int CollectedPhoneEvidenceCount => Session == null ? 0 : Session.CollectedEvidenceIds.Count;
        public int RequiredPhoneEvidenceCount => PhoneLevel == null ? 0 : PhoneLevel.RequiredEvidenceCount;
        public double CallDurationSeconds => CallState == PhoneCallState.InCall
            ? Time.realtimeSinceStartupAsDouble - callStartedAt : completedCallDurationSeconds;
        public event Action Changed;
        public bool HasPlaylist => playlist != null;
        public bool CanStartNextScenario => HasPlaylist && Session != null && Session.IsComplete
            && (pendingScenarios.Count > 0 || (playlist.Loop && availableScenarios.Count > 0));


        public void CancelEvidenceSubmission()
        {
            if (Session != null && Session.CloseEvidenceSubmission())
                Changed?.Invoke();
        }

        public void SubmitEvidence(
            System.Collections.Generic.IReadOnlyList<string> selectedIds)
        {
            if (!IsEmailScenario || Session == null ||
                !Session.SubmitEvidence(selectedIds, ElapsedSeconds))
                return;

            Result = ScenarioEvaluator.Evaluate(definition, Session);
            Changed?.Invoke();
        }


        public VerificationPageDefinition CurrentVerificationPage
        {
            get
            {
                if (Session == null || Session.CurrentVerificationPageId == null) return null;
                foreach (var page in BrowserPages())
                    if (page != null && page.Id == Session.CurrentVerificationPageId) return page;
                return null;
            }
        }

        private void Start()
        {
            if (playlist == null)
            {
                Restart();
                return;
            }

            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var entry in playlist.Entries)
            {
                if (entry == null || !entry.IsValid || !ids.Add(entry.Id))
                {
                    Debug.LogWarning("情景列表中有无效或重复的情景，已跳过。", this);
                    continue;
                }
                availableScenarios.Add(entry);
            }

            if (availableScenarios.Count == 0)
            {
                Debug.LogError("情景列表没有可用的情景，请检查邮件数据或电话情景 ID。", this);
                Changed?.Invoke();
                return;
            }

            RefillScenarioQueue();
            StartQueuedScenario();
        }

        public void NextScenario()
        {
            if (!CanStartNextScenario) return;
            if (pendingScenarios.Count == 0) RefillScenarioQueue();
            StartQueuedScenario();
        }

        private void RefillScenarioQueue()
        {
            pendingScenarios.Clear();
            var round = new List<ScenarioPlaylistEntry>(availableScenarios);
            if (playlist.Shuffle)
            {
                for (int i = round.Count - 1; i > 0; i--)
                {
                    int other = UnityEngine.Random.Range(0, i + 1);
                    var entry = round[i];
                    round[i] = round[other];
                    round[other] = entry;
                }
                // Avoid repeating the last scenario across rounds.
                if (round.Count > 1 && round[0] == currentEntry)
                {
                    int other = UnityEngine.Random.Range(1, round.Count);
                    round[0] = round[other];
                    round[other] = currentEntry;
                }
            }
            foreach (var entry in round) pendingScenarios.Enqueue(entry);
        }

        private void StartQueuedScenario()
        {
            currentEntry = pendingScenarios.Dequeue();
            scenarioType = currentEntry.Type;
            definition = currentEntry.Email;
            phoneCollection = currentEntry.PhoneCollection;
            phoneLevelIndex = currentEntry.Type == ScenarioType.Phone ? currentEntry.PhoneLevelIndex : 0;
            Restart();
        }

        public void Restart()
        {
            Session = null;
            Result = null;
            PhoneLevel = null;
            ResetPhoneProgress();

            string scenarioId;
            string emailId = null;
            switch (scenarioType)
            {
                case ScenarioType.Email:
                    if (definition == null || definition.Email == null
                        || string.IsNullOrWhiteSpace(definition.Id)
                        || string.IsNullOrWhiteSpace(definition.Email.Id))
                    {
                        Debug.LogError("Email 模式需要有效的 EmailScenarioDefinition 和邮件 ID。", this);
                        Changed?.Invoke();
                        return;
                    }
                    scenarioId = definition.Id;
                    emailId = definition.Email.Id;
                    break;
                case ScenarioType.Phone:
                    if (!SetPhoneLevel(phoneLevelIndex))
                    {
                        Changed?.Invoke();
                        return;
                    }
                    scenarioId = PhoneLevel.Id;
                    break;
                default:
                    Debug.LogError($"不支持的场景类型：{scenarioType}。", this);
                    Changed?.Invoke();
                    return;
            }

            startedAt = Time.realtimeSinceStartupAsDouble;
            Session = new ScenarioSession(scenarioId, emailId);
            Changed?.Invoke();
        }

        public void LoadPhoneLevel(int index)
        {
            if (!IsPhoneScenario)
            {
                Debug.LogError("只有 Phone 模式可以加载电话关卡。", this);
                return;
            }

            if (SetPhoneLevel(index))
                Restart();
        }

        private bool SetPhoneLevel(int index)
        {
            if (phoneCollection == null)
            {
                Debug.LogError("ScenarioController 缺少 PhoneScenarioCollection 资产。", this);
                return false;
            }

            if (index < 0 || index >= phoneCollection.Levels.Count)
            {
                Debug.LogError($"手机关卡索引 {index} 超出配置范围。", this);
                return false;
            }

            var level = phoneCollection.Levels[index];
            if (level == null || string.IsNullOrWhiteSpace(level.Id))
            {
                Debug.LogError($"手机关卡 {index} 缺少关卡数据或 ID。", this);
                return false;
            }

            phoneLevelIndex = index;
            PhoneLevel = level;
            ResetPhoneProgress();
            return true;
        }

        private void ResetPhoneProgress()
        {
            collectedPhoneEvidenceIds.Clear();
            PhoneDecision = null;
            PhoneOutcomeTitle = string.Empty;
            PhoneOutcomeBody = string.Empty;
            CallState = PhoneCallState.Incoming;
            callStartedAt = 0d;
            completedCallDurationSeconds = 0d;
        }

        public bool HasCollectedPhoneEvidence(string lineId) =>
            Session != null && Session.HasCollectedEvidence(lineId);

        public bool CollectPhoneEvidence(string lineId)
        {
            if (!IsPhoneScenario || CallState != PhoneCallState.InCall || PhoneLevel == null
                || string.IsNullOrWhiteSpace(lineId))
                return false;

            var line = PhoneLevel.FindDialogLine(lineId);
            if (line == null || !line.IsEvidence || collectedPhoneEvidenceIds.Contains(lineId)
                || Session == null || !Session.CollectPhoneEvidence(lineId, ElapsedSeconds))
                return false;

            collectedPhoneEvidenceIds.Add(lineId);
            Changed?.Invoke();
            return true;
        }

        public void AnswerCall()
        {
            if (!IsPhoneScenario || CallState != PhoneCallState.Incoming || PhoneLevel == null) return;
            CallState = PhoneCallState.InCall;
            callStartedAt = Time.realtimeSinceStartupAsDouble;
            Changed?.Invoke();
        }

        public void HangUp()
        {
            if (!IsPhoneScenario || CallState == PhoneCallState.Completed) return;

            bool verified = CallState == PhoneCallState.InCall
                && RequiredPhoneEvidenceCount > 0
                && PhoneLevel.IsRequiredEvidenceCollected(Session);
            FinishPhoneCall(verified ? PhoneResponse.Report : PhoneResponse.Ignore);
        }

        public void ChoosePhoneResponse(PhoneResponse response)
        {
            if (!IsPhoneScenario || CallState != PhoneCallState.InCall) return;
            FinishPhoneCall(response);
        }

        private void FinishPhoneCall(PhoneResponse response)
        {
            if (PhoneLevel == null) return;

            var outcome = PhoneLevel.FindOutcome(response);
            if (outcome == null)
            {
                Debug.LogError($"手机关卡 {PhoneLevel.Id} 未配置 {response} 结局。", this);
                return;
            }

            if (!TryChoosePhoneResponse(ToContactResponse(response)))
            {
                Debug.LogError($"手机回应 {response} 无法记录到当前会话。", this);
                return;
            }

            completedCallDurationSeconds = CallDurationSeconds;
            PhoneDecision = response;
            PhoneOutcomeTitle = outcome.Title;
            PhoneOutcomeBody = outcome.Body;
            CallState = PhoneCallState.Completed;
            Changed?.Invoke();
        }

        private bool TryChoosePhoneResponse(ContactResponse response)
        {
            return Session != null && Session.ChoosePhoneResponse(response, ElapsedSeconds);
        }

        private static ContactResponse ToContactResponse(PhoneResponse response)
        {
            switch (response)
            {
                case PhoneResponse.Trust: return ContactResponse.Proceed;
                case PhoneResponse.Ignore: return ContactResponse.Ignore;
                case PhoneResponse.Report: return ContactResponse.Reject;
                default: throw new ArgumentOutOfRangeException(nameof(response), response, null);
            }
        }

        public void OpenPhone()
        {
            if (IsPhoneScenario && Session != null && Session.OpenPhone(ElapsedSeconds)) Changed?.Invoke();
        }
        public void ClosePhone()
        {
            if (IsPhoneScenario && Session != null && Session.ClosePhone(ElapsedSeconds)) Changed?.Invoke();
        }

        public void StopPhoneContact()
        {
            if (IsPhoneScenario && Session != null && Session.ClosePhone(true, ElapsedSeconds)) Changed?.Invoke();
        }

        public void OpenEmail()
        {
            if (IsEmailScenario && Session != null && Session.OpenEmail(ElapsedSeconds)) Changed?.Invoke();
        }

        public void CloseEmail()
        {
            if (IsEmailScenario && Session != null && Session.CloseEmail(false, ElapsedSeconds)) Changed?.Invoke();
        }

        public void StopContact()
        {
            if (IsEmailScenario && Session != null && Session.CloseEmail(true, ElapsedSeconds)) Changed?.Invoke();
        }

        public void ChooseResponse(ContactResponse response)
        {
            if (!IsEmailScenario || definition == null
                || Session == null || !Session.IsEmailOpen || Session.IsComplete) return;
            // Opening a link does not submit information.
            if (response == ContactResponse.Proceed && !string.IsNullOrWhiteSpace(definition.Email.ProceedLink))
            {
                OpenLink(definition.Email.ProceedLink);
                return;
            }
            if (!Session.ChooseResponse(response, ElapsedSeconds)) return;
            // Notify views after the result is complete.
            if (Session.IsComplete)
            {
                Result = ScenarioEvaluator.Evaluate(definition, Session);
            }

            Changed?.Invoke();
        }

        public void OpenBrowser()
        {
            if (Session != null && Session.OpenBrowser(ElapsedSeconds)) Changed?.Invoke();
        }

        public void CloseBrowser()
        {
            if (Session != null && Session.CloseBrowser(ElapsedSeconds)) Changed?.Invoke();
        }

        public void OpenBrowserHome()
        {
            if (Session != null && Session.OpenBrowserHome()) Changed?.Invoke();
        }

        public void OpenVerificationPage(VerificationPageDefinition page)
        {
            if (Session == null
                || page == null || string.IsNullOrWhiteSpace(page.Id)) return;
            foreach (var available in VerificationPages)
            {
                if (available != page || page.IsUnsafe) continue;
                if (Session.OpenVerificationPage(page.Id, ElapsedSeconds)) Changed?.Invoke();
                return;
            }
        }

        public void OpenLink(string address)
        {

            if (Session == null ||
                Session.IsComplete ||
                Session.IsEvidenceSubmissionOpen ||
                string.IsNullOrWhiteSpace(address))
                return;

            foreach (var page in BrowserPages())
            {
                if (page == null || string.IsNullOrWhiteSpace(page.Id)
                    || !string.Equals(page.Address, address, StringComparison.Ordinal)) continue;
                double elapsed = ElapsedSeconds;
                Session.CloseEvidenceSummary();
                if (Session.IsReminderVisible) Session.DismissReminder(elapsed);
                Session.OpenBrowser(elapsed);
                Session.OpenVerificationPage(page.Id, elapsed);
                if (page.IsUnsafe) Session.RecordUnsafeLinkOpened(page.Id, elapsed);
                Changed?.Invoke();
                return;
            }
            Debug.LogWarning("链接未配置对应的本关页面：" + address, this);
        }

        public void SubmitBrowserInformation()
        {
            var page = CurrentVerificationPage;
            if (Session == null || page == null || !page.IsUnsafe) return;

            if (IsPhoneScenario)
            {
                var outcome = PhoneLevel != null ? PhoneLevel.FindOutcome(PhoneResponse.Trust) : null;
                if (outcome == null)
                {
                    Debug.LogError("Phone 关卡未配置 Trust 结局，无法提交验证信息。", this);
                    return;
                }
                if (!Session.SubmitInformation(page.Id, ElapsedSeconds)) return;
                CompletePhoneDecision(PhoneResponse.Trust, outcome);
                return;
            }

            if (!IsEmailScenario || definition == null
                || !Session.SubmitInformation(page.Id, ElapsedSeconds)) return;
            Result = ScenarioEvaluator.Evaluate(definition, Session);
            Changed?.Invoke();
        }

        private System.Collections.Generic.IEnumerable<VerificationPageDefinition> BrowserPages()
        {
            foreach (var page in VerificationPages) yield return page;
            foreach (var page in LinkedPages) yield return page;
        }

        private double ElapsedSeconds => Time.realtimeSinceStartupAsDouble - startedAt;

        public EvidencePlacement FindEvidencePlacement(string id)
        {
            if (IsPhoneScenario)
                return PhoneLevel != null ? PhoneLevel.FindEvidencePlacement(id) : null;
            if (definition == null) return null;
            foreach (var placement in EvidencePlacements)
                if (placement != null && placement.Evidence != null && placement.Evidence.Id == id)
                    return placement;
            return null;
        }

        public void CollectEvidence(EvidencePlacement placement)
        {
            if (Session == null
                || placement == null || placement.Evidence == null
                || string.IsNullOrWhiteSpace(placement.Evidence.Id)
                || placement.Page != CurrentVerificationPage) return;

            foreach (var available in EvidencePlacements)
            {
                if (available == null || available != placement) continue;
                if (!Session.CollectEvidence(placement.Evidence.Id, ElapsedSeconds)) return;
                if (IsEmailScenario && definition != null)
                {
                    var reminder = definition.Reminder;
                    if (reminder != null && !string.IsNullOrWhiteSpace(reminder.Id)
                        && Session.CollectedEvidenceIds.Count >= reminder.TriggerEvidenceCount)
                        Session.TriggerReminder(reminder.Id, ElapsedSeconds);
                }
                Changed?.Invoke();
                return;
            }
        }

        private void CompletePhoneDecision(PhoneResponse response, PhoneOutcomeData outcome)
        {
            if (CallState == PhoneCallState.InCall)
                completedCallDurationSeconds = CallDurationSeconds;
            PhoneDecision = response;
            PhoneOutcomeTitle = outcome.Title;
            PhoneOutcomeBody = outcome.Body;
            CallState = PhoneCallState.Completed;
            Changed?.Invoke();
        }

        public void OpenEvidenceSummary()
        {
            if (Session != null && Session.OpenEvidenceSummary(ElapsedSeconds)) Changed?.Invoke();
        }

        public void CloseEvidenceSummary()
        {
            if (Session != null && Session.CloseEvidenceSummary()) Changed?.Invoke();
        }

        public void DismissReminder()
        {
            if (IsEmailScenario && Session != null && Session.DismissReminder(ElapsedSeconds)) Changed?.Invoke();
        }
    }
}
